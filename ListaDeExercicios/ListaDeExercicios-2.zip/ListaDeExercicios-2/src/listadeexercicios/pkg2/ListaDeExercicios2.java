/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios.pkg2;

import javax.swing.JOptionPane;

/**
 *
 * @author 0031432412008
 */
public class ListaDeExercicios2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Funcionario F = new Funcionario();

        int escolha;
        do {
            escolha = Integer.parseInt(JOptionPane.showInputDialog(null, "1 - Criar Funcionario \n"
                    + "2 - Mostrar Folha de Pagamento \n"
                    + "3 - Alterar Remuneração \n"
                    + "4 - Sair \n"
                    + "Selecione uma opção:"));

            switch (escolha) {
                case 1:
                    F.setCracha(Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o seu crachá")));
                    F.setNome(JOptionPane.showInputDialog(null, "Digite o seu nome"));
                    F.setTipoVinculo();
                    F.setQtdeHora(Float.parseFloat(JOptionPane.showInputDialog(null, "Digite a quantidade de horas")));
                    F.setValorHora(Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o valor por hora")));
                    F.setValorDesconto(Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o valor de desconto")));
                    break;
                case 2:
                    JOptionPane.showMessageDialog(null, F.imprimir());
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, "Opçãodshgdsa!");
                    break;
                case 4:
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opção inválida!");
                    break;
            }
        } while (escolha != 4);
    }
    
}

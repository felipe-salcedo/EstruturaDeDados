/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios.pkg2;

import javax.swing.JOptionPane;

/**
 *
 * @author 0031432412008
 */
public class Funcionario {
    int cracha = 0;
    String nome = "";
    char tipoVinculo = 0;
    float valorHora = 0;
    float qtdeHora = 0;
    float salario = 0;
    float valorDesconto = 0;
    
    public void setCracha(int cracha) {
        this.cracha = cracha;
    }
    
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public void setTipoVinculo() {
        Object[] opcoes = {"C - CLT", "E - Estagiário", "A - Autônomo", "D - Doméstico"};
        int escolha = JOptionPane.showOptionDialog(null, "Selecione o seu vínculo:", "Seleção de vínculo", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, opcoes, opcoes[0]);

        if (escolha == 0) {
            this.tipoVinculo = 'C';
        } else if (escolha == 1) {
            this.tipoVinculo = 'E';
        } else if (escolha == 2) {
            this.tipoVinculo = 'A';
        } else if (escolha == 3) {
            this.tipoVinculo = 'D';
        }
    }
    
    public void setValorHora(float valorHora) {
        this.valorHora = valorHora;
    }
    
    public void setQtdeHora(float qtdeHora) {
        this.qtdeHora = qtdeHora;
    }
    
    public void setSalario(float salario) {
        this.salario = salario;
    }
    
    public void setValorDesconto(float valorDesconto) {
        this.valorDesconto = valorDesconto;
    }
    
    public int getCracha() {
        return cracha;
    }
    
    public String getNome() {
        return nome;
    }
    
    public char getTipoVinculo() {
        return tipoVinculo;
    }
    
    public float getQtdeHora() {
        return qtdeHora;
    }
    
    public float getValorHora() {
        return valorHora;
    }
    
    public float getSalario() {
        if(tipoVinculo == 'C') {
            return valorHora * qtdeHora - valorDesconto;
        } else {
            return salario - valorDesconto;
        }
    }
    
    public float getValorDesconto() {
        return valorDesconto;
    }
    
    public String imprimir() {
        StringBuilder resultado = new StringBuilder();
        resultado.append("Cracha: ").append(getCracha()).append("\n");
        resultado.append("Nome: ").append(getNome()).append("\n");
        resultado.append("Vínculo: ").append(getTipoVinculo()).append("\n");
        resultado.append("Valor p/ hora: ").append(getValorHora()).append("\n");
        resultado.append("Quantidade de horas: ").append(getQtdeHora()).append("\n");
        resultado.append("Salário: ").append(getSalario()).append("\n");
        resultado.append("Valor de desconto: ").append(getValorDesconto()).append("\n");
        return resultado.toString();
    }
}

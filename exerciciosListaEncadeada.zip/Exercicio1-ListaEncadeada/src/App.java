import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args) {
        ListaEncadeada lista = new ListaEncadeada();

        int numElem, valor;

        numElem = Integer.parseInt(JOptionPane.showInputDialog("Informe o número " +
                "de elementos a serem inseridos na lista: "));
        for (int i = 0; i < numElem; i++) {
            valor = Integer.parseInt(JOptionPane.showInputDialog("Informe o " +
                    "valor a ser inserido na lista: "));
            if (valor == 0) {
                break;
            } else {
                lista.insereNo_inicio(new IntNoSimples(valor));
            }
        }
        lista.exibeLista();
    }
}

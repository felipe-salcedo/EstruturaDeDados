
public class IntNoSimples {
    int valor;
    IntNoSimples prox;

    IntNoSimples(int ValorNo) {
        valor = ValorNo;
        prox = null;
    }
}

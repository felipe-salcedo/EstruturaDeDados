import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args) {
        ListaEncadeada lista = new ListaEncadeada();
        int numElem, numero;
        numElem = Integer.parseInt(
                JOptionPane.showInputDialog("Informe a quantidade de elementos "
                        + "a serem inseridos na pilha:"));

        Pilha p = new Pilha(numElem);

        for (int i = 0; i < numElem; i++) {
            numero = Integer.parseInt(
                    JOptionPane.showInputDialog("Informe o valor a ser"
                            + "inserido na pilha:"));
            p.empilhar(numero);
        }

        while (!p.vazia()) {
            numero = Integer.parseInt(p.desempilhar().toString());
            lista.insereNo_inicio(new IntNoSimples(numero));
            lista.exibeLista();
        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayexercicio2;
import javax.swing.JOptionPane;

/**
 *
 * @author 0031432412008
 */
public class ArrayExercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Solicita ao usuário o tamanho do primeiro array
        int size1 = Integer.parseInt(JOptionPane.showInputDialog("Digite o tamanho do primeiro array:"));
        
        // Cria o primeiro array e preenche com valores fornecidos pelo usuário
        int[] v1 = new int[size1];
        for (int i = 0; i < size1; i++) {
            v1[i] = Integer.parseInt(JOptionPane.showInputDialog("Digite o valor " + (i + 1) + " do primeiro array:"));
        }

        // Solicita ao usuário o tamanho do segundo array
        int size2 = Integer.parseInt(JOptionPane.showInputDialog("Digite o tamanho do segundo array:"));
        
        // Cria o segundo array e preenche com valores fornecidos pelo usuário
        int[] v2 = new int[size2];
        for (int i = 0; i < size2; i++) {
            v2[i] = Integer.parseInt(JOptionPane.showInputDialog("Digite o valor " + (i + 1) + " do segundo array:"));
        }

        // Cria o terceiro array com tamanho total da união dos dois arrays
        int size3 = size1 + size2;
        int[] v3 = new int[size3];

        // Copia os elementos do primeiro array para o terceiro array
        for (int i = 0; i < size1; i++) {
            v3[i] = v1[i];
        }

        // Copia os elementos do segundo array para o terceiro array, começando do final do primeiro array
        for (int i = 0; i < size2; i++) {
            v3[size1 + i] = v2[i];
        }

        // Cria uma string para exibir o terceiro array
        StringBuilder result = new StringBuilder("A união dos arrays é: {");
        for (int i = 0; i < size3; i++) {
            result.append(v3[i]);
            if (i < size3 - 1) {
                result.append(", ");
            }
        }
        result.append("}");

        // Exibe o resultado em uma caixa de mensagem
        JOptionPane.showMessageDialog(null, result.toString());
    }
    
}

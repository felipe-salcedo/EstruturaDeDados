/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayexercicio1;
import javax.swing.JOptionPane;
/**
 *
 * @author 0031432412008
 */
public class ArrayExercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int n;
        int m;
        
        n = Integer.parseInt(JOptionPane.showInputDialog("Digite o número de linhas (N): "));
        m = Integer.parseInt(JOptionPane.showInputDialog("Digite o número de colunas (M): "));
        
        int[][] matriz = new int[n][m];
        
        for(int i =0; i < n; i++){
            for(int j = 0; j < m; j++){
                matriz[i][j] = Integer.parseInt(JOptionPane.showInputDialog("Digite o valor"
                        + "para a posição [" + i + "][" + j + "]: "));
            }
        }
        
        int maiorValor = matriz[0][0];
        int linhaMaior = 0;
        int colunaMaior = 0;
        
        for(int i = 0; i < n; i++){
            for(int j = 0; j < m; j++){
                if(matriz[i][j] > maiorValor){
                    maiorValor = matriz[i][j];
                    linhaMaior = i;
                    colunaMaior = j;
                }
            }
        }
        
        JOptionPane.showMessageDialog(null, "O maior valor na matriz é : " + maiorValor +
        ", na posição [" + linhaMaior + "][" + colunaMaior + "].");
    }
}

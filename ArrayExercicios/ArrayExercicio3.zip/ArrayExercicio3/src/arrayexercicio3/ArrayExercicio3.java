/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayexercicio3;
import javax.swing.JOptionPane;
/**
 *
 * @author 0031432412008
 */
public class ArrayExercicio3 {
    public static void main(String[] args) {
        int tamanhoMatriz = Integer.parseInt(JOptionPane.showInputDialog("Digite o tamanho da matriz quadrada:"));
        int[][] matriz = new int[tamanhoMatriz][tamanhoMatriz];
        
        for (int i = 0; i < tamanhoMatriz; i++) {
            for (int j = 0; j < tamanhoMatriz; j++) {
                matriz[i][j] = Integer.parseInt(JOptionPane.showInputDialog("Digite o valor para a posição [" + i + "][" + j + "] da matriz:"));
            }
        }
        
        int somaDiagonalPrincipal = 0;
        for (int i = 0; i < tamanhoMatriz; i++) {
            somaDiagonalPrincipal += matriz[i][i];
        }
        
        JOptionPane.showMessageDialog(null, "A soma dos elementos da diagonal principal é: " + somaDiagonalPrincipal);
    }
}

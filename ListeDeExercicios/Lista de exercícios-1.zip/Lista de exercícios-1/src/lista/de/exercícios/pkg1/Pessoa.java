/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lista.de.exercícios.pkg1;

import javax.swing.JOptionPane;

/**
 *
 * @author 0031432412008
 */
public class Pessoa {
    String cpf = "";
    String nome = "";
    char sexo = 0;
    int idade = 0;
    int pessoa = 0;

    public void setCPF(String cpf) {
        this.cpf = cpf;
    }
    
    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setSexo() {
        Object[] opcoes = {"Masculino", "Feminino"};
        int escolha = JOptionPane.showOptionDialog(null, "Selecione o seu sexo:", "Seleção de Sexo", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, opcoes, opcoes[0]);

        if (escolha == 0) {
            this.sexo = 'M';
        } else if (escolha == 1) {
            this.sexo = 'F';
        }
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    // Métodos get para cada atributo
    public String getCPF() {
        return cpf;
    }

    public String getNome() {
        return nome;
    }

    public char getSexo() {
        return sexo;
    }

    public int getIdade() {
        return idade;
    }
    
    public String imprimir() {
        StringBuilder resultado = new StringBuilder();
        resultado.append("CPF: ").append(getCPF()).append("\n");
        resultado.append("Nome: ").append(getNome()).append("\n");
        resultado.append("Sexo: ").append(getSexo()).append("\n");
        resultado.append("Idade: ").append(getIdade()).append("\n");
        return resultado.toString();
    }
}

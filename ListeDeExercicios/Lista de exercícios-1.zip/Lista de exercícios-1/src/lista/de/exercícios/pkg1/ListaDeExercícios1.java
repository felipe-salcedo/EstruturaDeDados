/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lista.de.exercícios.pkg1;

import javax.swing.JOptionPane;

/**
 *
 * @author 0031432412008
 */
public class ListaDeExercícios1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Pessoa P = new Pessoa();

        int escolha;
        do {
            escolha = Integer.parseInt(JOptionPane.showInputDialog(null, "1 - Criar Pessoa \n"
                    + "2 - Mostrar Pessoa \n"
                    + "3 - Sair \n"
                    + "Selecione uma opção:"));

            switch (escolha) {
                case 1:
                    P.setCPF(JOptionPane.showInputDialog(null, "Digite o seu CPF"));
                    P.setNome(JOptionPane.showInputDialog(null, "Digite o seu nome"));
                    P.setSexo();
                    P.setIdade(Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a sua idade")));
                    break;
                case 2:
                    JOptionPane.showMessageDialog(null, P.imprimir());
                    break;
                case 3:
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opção inválida!");
                    break;
            }
        } while (escolha != 3);
    }
}

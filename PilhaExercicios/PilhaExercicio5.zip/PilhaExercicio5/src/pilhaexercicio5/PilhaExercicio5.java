/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pilhaexercicio5;

import javax.swing.JOptionPane;
import java.util.Stack;

public class PilhaExercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Stack<String> historico = new Stack<>();
        
        while (true) {
            String url = JOptionPane.showInputDialog("Digite a URL do site que deseja acessar (ou digite 'Voltar' para retornar à página anterior):");
            
            if (url.equalsIgnoreCase("Voltar")) {
                if (historico.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Não há páginas para voltar.");
                } else {
                    String paginaAnterior = historico.pop();
                    JOptionPane.showMessageDialog(null, "Você voltou para: " + paginaAnterior);
                }
            } else {
                historico.push(url);
                JOptionPane.showMessageDialog(null, "Você acessou: " + url);
            }
        }
    }
    
}

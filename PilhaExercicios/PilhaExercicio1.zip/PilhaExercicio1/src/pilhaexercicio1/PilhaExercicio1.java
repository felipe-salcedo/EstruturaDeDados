/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pilhaexercicio1;

import javax.swing.JOptionPane;
import java.util.ArrayList;
/**
 *
 * @author 0031432412008
 */
public class PilhaExercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Integer> numeros = new ArrayList<>();
        int qtdMax;
        
        qtdMax = Integer.parseInt(JOptionPane.showInputDialog("Informe a quantidade máxia "
                + "de números a serem armazenados: "));
        
        JOptionPane.showMessageDialog(null, "Digite os números inteiros para serem armazenados "
                + "na pilha. \nPressione OK para cada número. \nDigite 0 para parar.");
        
        int numero;
        do {
             numero = Integer.parseInt(JOptionPane.showInputDialog("Digite um número inteiro: "));
             
             if(numero != 0) {
                 numeros.add(numero);
             }
        }while(numero !=0 && numeros.size() < qtdMax);
        
        JOptionPane.showMessageDialog(null, "Os números armazenados na pilha, na ordem que foram removidos são: ");
        
        StringBuilder resultado = new StringBuilder();
        
        for(int i = numeros.size() - 1; i >= 0; i--) {
            resultado.append(numeros.get(i)).append("\n");
        }
        
        JOptionPane.showMessageDialog(null, resultado.toString());
    }
}

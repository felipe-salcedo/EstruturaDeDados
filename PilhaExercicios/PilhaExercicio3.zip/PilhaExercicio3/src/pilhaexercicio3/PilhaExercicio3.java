/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pilhaexercicio3;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author 0031432412008
 */
public class PilhaExercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Integer> numeros = new ArrayList<>();
        int qtdMax;
        
        qtdMax = Integer.parseInt(JOptionPane.showInputDialog("Informe a quantidade máxima "
                + "de números a serem armazenados: "));
        
        JOptionPane.showMessageDialog(null, "Digite os números inteiros para serem armazenados "
                + "na pilha. \nPressione OK para cada número. \nDigite 0 para parar.");
        
        int numero;
        do {
             numero = Integer.parseInt(JOptionPane.showInputDialog("Digite um número inteiro: "));
             
             if(numero != 0) {
                 numeros.add(numero);
             }
        } while(numero != 0 && numeros.size() < qtdMax);
        
        int countPares = 0; // contador para números pares
        StringBuilder resultado = new StringBuilder();
        
        for(int i = numeros.size() - 1; i >= 0; i--) {
            int num = numeros.get(i);
            resultado.append(num).append("\n");
            if (num % 2 == 0) { // verifica se o número é par
                countPares++;
            }
        }
        
        JOptionPane.showMessageDialog(null, "Os números armazenados na pilha, na ordem que foram removidos são: \n" + resultado.toString());
        JOptionPane.showMessageDialog(null, "Número de elementos pares na pilha: " + countPares);
    }
}

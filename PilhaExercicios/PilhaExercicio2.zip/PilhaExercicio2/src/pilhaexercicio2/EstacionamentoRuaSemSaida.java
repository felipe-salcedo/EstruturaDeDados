/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pilhaexercicio2;

import java.util.Stack;

/**
 *
 * @author 0031432412008
 */
public class EstacionamentoRuaSemSaida {
    private Stack<String>carrosEstacionados;
    
    public EstacionamentoRuaSemSaida() {
        carrosEstacionados = new Stack<>();
    }
    
    public void estacionarCarro(String placa) {
        carrosEstacionados.push(placa);
    }
    
    public String verificarCarro(String placa) {
        Stack<String> aux = new Stack<>();
        String sequenciaSaida = "";
        
        while(!carrosEstacionados.isEmpty()) {
            String carroAtual = carrosEstacionados.pop();
            aux.push(carroAtual);
            sequenciaSaida += carroAtual + "\n";
            
            if(carroAtual.equals(placa)) {
                while(!aux.isEmpty()) {
                    carrosEstacionados.push(aux.pop());
                }
                return sequenciaSaida;
            }
        }
        while(!aux.isEmpty()) {
            carrosEstacionados.push(aux.pop());
        }
        return "Carro não encontrado no estacionamento!!!";
    }
}
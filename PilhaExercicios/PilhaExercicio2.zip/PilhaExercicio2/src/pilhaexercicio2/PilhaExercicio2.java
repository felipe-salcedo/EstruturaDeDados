/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pilhaexercicio2;

import javax.swing.JOptionPane;

/**
 *
 * @author 0031432412008
 */
public class PilhaExercicio2 {
    
    public static void main(String[] args) {
        EstacionamentoRuaSemSaida estacionamento = new EstacionamentoRuaSemSaida();
        
        estacionamento.estacionarCarro("ABC1234");
        estacionamento.estacionarCarro("DEF5678");
        estacionamento.estacionarCarro("GHI9012");
        
        String placa = JOptionPane.showInputDialog("Escolha a placa do carro que deseja sair: \n"
                + "ABC1234 \n"
                + "DEF5678 \n"
                + "GHI9012");
        
        String sequenciaSaida = estacionamento.verificarCarro(placa);
        
        JOptionPane.showMessageDialog(null, "Sequência de carros a ser retirada para o carro com placa "
                + placa + " sair é:\n\n" + sequenciaSaida);
    }
    
}

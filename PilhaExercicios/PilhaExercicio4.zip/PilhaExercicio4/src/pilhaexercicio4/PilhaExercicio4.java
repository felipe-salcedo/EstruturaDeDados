/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pilhaexercicio4;

import javax.swing.JOptionPane;
import java.util.Stack;

/**
 *
 * @author 0031432412008
 */
public class PilhaExercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         int[] array = new int[8];

        for (int i = 0; i < array.length; i++) {
            String input = JOptionPane.showInputDialog("Informe o número inteiro para a posição " + i + ":");
            array[i] = Integer.parseInt(input);
        }

        Stack<Integer> pilhaN = new Stack<>();
        Stack<Integer> pilhaP = new Stack<>();

        for (int i = 0; i < array.length; i++) {
            if (array[i] > 0) {
                pilhaP.push(array[i]);
            } else if (array[i] < 0) {
                pilhaN.push(array[i]);
            } else {
                if (!pilhaN.isEmpty()) {
                    pilhaN.pop();
                }
                if (!pilhaP.isEmpty()) {
                    pilhaP.pop();
                }
            }
        }

        JOptionPane.showMessageDialog(null, "Pilha dos números negativos: " + pilhaN);
        JOptionPane.showMessageDialog(null, "Pilha dos números positivos: " + pilhaP);
    }
}
